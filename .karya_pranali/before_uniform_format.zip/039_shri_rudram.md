---
title: "श्रीरुद्रम्"
sequence: 39
language: sa
script: Devanagari
tags: [shri_bhajanam, shiva, index]
sources:
  - https://sanskritdocuments.org/doc_veda/rudra.html
  - https://sanskritdocuments.org/doc_veda/chamaka.html
source_accessed: 2026-09-18
---

# श्रीरुद्रम्

[[000_master_list|← मुख्य सूची]]

श्रीरुद्रम् के दोनों भाग नीचे की मूल फ़ाइलों में हैं। पाठ के लिए क्रम से इन्हें खोलें:

1. [[037_shri_namakam|नमकम् — लघुन्यास सहित]]
2. [[038_shri_chamakam|चमकम्]]
