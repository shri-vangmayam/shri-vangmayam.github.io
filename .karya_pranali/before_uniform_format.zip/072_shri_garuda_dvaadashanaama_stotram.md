---
title: "गरुड द्वादशनाम स्तोत्रम्"
sequence: 72
original_list_number: 74
language: sa
script: Devanagari
tags: [shri_bhajanam, stotra]
sources:
  - https://sanskritdocuments.org/doc_deities_misc/garuDadvAdashanAmastotram.html
source_accessed: 2026-09-18
---

# गरुड द्वादशनाम स्तोत्रम्

[[000_master_list|← मुख्य सूची]]

> प्रकाशित स्रोत का देवनागरी पाठ। रचना के समान नाम वाले अन्य पाठ भी हो सकते हैं; नीचे दिया स्रोत इस चयन की पहचान है।

## मूल पाठ

सुपर्णं वैनतेयं च नागारिं नागभीषणम् ।  
जितान्तकं विषारिं च अजितं विश्वरूपिणम् ।  
गरुत्मन्तं खगश्रेष्ठं तार्क्ष्यं कश्यपनन्दनम् ॥ १॥  

द्वादशैतानि नामानि गरुडस्य महात्मनः ।  
यः पठेत् प्रातरुत्थाय स्नाने वा शयनेऽपि वा ॥ २॥  

विषं नाक्रामते तस्य न च हिंसन्ति हिंसकाः ।  
सङ्ग्रामे व्यवहारे च विजयस्तस्य जायते ।  
बन्धनान्मुक्तिमाप्नोति यात्रायां सिद्धिरेव च ॥ ३॥  

॥ इति बृहद्तन्त्रसारे श्रीगरुडस्य द्वादशनामस्तोत्रं सम्पूर्णम् ॥  

## स्रोत

[Sanskrit Documents](https://sanskritdocuments.org/doc_deities_misc/garuDadvAdashanAmastotram.html)
