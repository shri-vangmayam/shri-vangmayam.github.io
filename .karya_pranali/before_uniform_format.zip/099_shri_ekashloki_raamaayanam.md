---
title: "एकश्लोकी रामायणम्"
sequence: 99
original_list_number: 102
language: sa
script: Devanagari
tags: [shri_bhajanam, stotra]
sources:
  - https://sanskritdocuments.org/doc_raama/ekashlokiraama.html
source_accessed: 2026-09-18
---

# एकश्लोकी रामायणम्

[[000_master_list|← मुख्य सूची]]

> प्रकाशित स्रोत का देवनागरी पाठ। रचना के समान नाम वाले अन्य पाठ भी हो सकते हैं; नीचे दिया स्रोत इस चयन की पहचान है।

## मूल पाठ

आदौ रामतपोवनादिगमनं हत्वा मृगं काञ्चनं  पूर्वं  
वैदेहीहरणं जटायुमरणं सुग्रीवसम्भाषणम् ।  
वालीनिर्दलनं समुद्रतरणं लङ्कापुरीदाहनं  
पश्चाद्रावणकुम्भकर्णहननमेतद्धि रामायणम् ॥  कुम्भकर्णकदनं  
इति एकश्लोकि रामायणं (१) सम्पूर्णम् ॥  

## स्रोत

[Sanskrit Documents](https://sanskritdocuments.org/doc_raama/ekashlokiraama.html)
