---
title: "दुर्गा सप्तश्लोकी"
sequence: 135
original_list_number: 139
language: sa
script: Devanagari
tags: [shri_bhajanam, stotra]
sources:
  - https://sanskritdocuments.org/doc_devii/durga7.html
source_accessed: 2026-09-18
---

# दुर्गा सप्तश्लोकी

[[000_master_list|← मुख्य सूची]]

> यह सात श्लोकों का स्वतंत्र पाठक्रम है। अधिकांश श्लोक देवीमाहात्म्य में भी हैं; नीचे मूल संग्रह से एम्बेड किए गए हैं। पहला श्लोक दो मूल श्लोकों के अर्धांश जोड़ता है, अतः उसका संकलित पाठ यहाँ रखा गया है। स्रोतों के छोटे पाठान्तर हेतु मूल लिंक देखें।

## मूल पाठ

। अथ सप्तश्लोकी दुर्गा ।  
शिव उवाच  
देवि त्वं भक्तसुलभे सर्वकार्यविधायिनी ।  
कलौ हि कार्यसिद्ध्यर्थमुपायं ब्रूहि यत्नतः ॥  

देव्युवाच  
श‍ृणु देव प्रवक्ष्यामि कलौ सर्वेष्टसाधनम् ।  
मया तवैव स्नेहेनाप्यम्बास्तुतिः प्रकाश्यते ॥  

ॐ अस्य श्रीदुर्गासप्तश्लोकीस्तोत्रमहामन्त्रस्य नारायण ऋषिः ।  
अनुष्टुभादीनि छन्दांसि । श्रीमहाकालीमहालक्ष्मीमहासरस्वत्यो देवताः ।  
श्रीदूर्गाप्रीत्यर्थं सप्तश्लोकी दुर्गापाठे विनियोगः ॥  

ज्ञानिनामपि चेतांसि देवी भगवती हि सा ।  
बलादाकृष्य मोहाय महामाया प्रयच्छति ॥ १॥  

![[128_shri_devimahaatmyam_durgaasaptashati#^dm-4-17]]

![[128_shri_devimahaatmyam_durgaasaptashati#^dm-11-10]]

![[128_shri_devimahaatmyam_durgaasaptashati#^dm-11-12]]

![[128_shri_devimahaatmyam_durgaasaptashati#^dm-11-24]]

![[128_shri_devimahaatmyam_durgaasaptashati#^dm-11-29]]

![[128_shri_devimahaatmyam_durgaasaptashati#^dm-11-39]]

## स्रोत

[Sanskrit Documents](https://sanskritdocuments.org/doc_devii/durga7.html)
